create table events(id uuid primary key default gen_random_uuid(),name text not null,event_date date not null,venue text,price_mxn numeric not null,active boolean default true);
create table orders(id uuid primary key default gen_random_uuid(),event_id uuid references events,qty int not null,amount numeric not null,status text default 'pending',payment_id text,created_at timestamptz default now());
create table tickets(id uuid primary key default gen_random_uuid(),order_id uuid references orders,event_id uuid references events,token text unique not null default encode(gen_random_bytes(16),'hex'),status text default 'valid',used_at timestamptz);
create table admins(user_id uuid primary key references auth.users);
alter table events enable row level security;alter table orders enable row level security;alter table tickets enable row level security;alter table admins enable row level security;
create function is_admin() returns boolean language sql security definer as $$select exists(select 1 from admins where user_id=auth.uid())$$;
create policy "ver eventos" on events for select using (active or is_admin());
create policy "admin eventos" on events for all using (is_admin()) with check (is_admin());
create policy "admin ordenes" on orders for select using (is_admin());
create policy "admin boletos" on tickets for select using (is_admin());
create policy "yo admin" on admins for select using (user_id=auth.uid());
-- Después de crear tu usuario en Authentication > Users, ejecuta:
-- insert into admins values ('PEGA_AQUI_TU_USER_ID');
