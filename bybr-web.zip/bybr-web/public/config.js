window.CFG={url:'https://TU-PROYECTO.supabase.co',key:'TU_ANON_PUBLIC_KEY'};
