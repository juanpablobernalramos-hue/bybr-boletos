import {sb} from './_db.js';
export default async function handler(req,res){
 const id=req.body?.data?.id||req.query['data.id'],type=req.body?.type||req.query.type||req.query.topic;
 if(!id||type!=='payment')return res.status(200).end();
 const p=await (await fetch('https://api.mercadopago.com/v1/payments/'+id,{headers:{Authorization:'Bearer '+process.env.MP_ACCESS_TOKEN}})).json();
 if(p.status==='approved'){
  const {data:o}=await sb.from('orders').update({status:'paid',payment_id:String(id)}).eq('id',p.external_reference).eq('status','pending').select().maybeSingle();
  if(o)await sb.from('tickets').insert(Array.from({length:o.qty},()=>({order_id:o.id,event_id:o.event_id})));
 }
 res.status(200).end();
}
