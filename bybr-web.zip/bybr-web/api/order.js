import {sb} from './_db.js';
export default async function handler(req,res){
 const {data:o}=await sb.from('orders').select('status,events(name,event_date,venue),tickets(token)').eq('id',req.query.id).maybeSingle();
 if(!o)return res.status(404).json({});
 res.json({status:o.status,event:o.events,tokens:o.status==='paid'?o.tickets.map(t=>t.token):[]});
}
