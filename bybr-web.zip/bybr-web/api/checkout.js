import {sb} from './_db.js';
export default async function handler(req,res){
 if(req.method!=='POST')return res.status(405).end();
 const qty=Math.min(5,Math.max(1,parseInt(req.body?.qty)||1));
 const {data:ev}=await sb.from('events').select('*').eq('id',req.body?.eventId).eq('active',true).maybeSingle();
 if(!ev)return res.status(404).json({error:'Evento no disponible'});
 const {data:o}=await sb.from('orders').insert({event_id:ev.id,qty,amount:ev.price_mxn*qty}).select().single();
 const b=process.env.BASE_URL,back=`${b}/?order=${o.id}`;
 const r=await fetch('https://api.mercadopago.com/checkout/preferences',{method:'POST',
  headers:{Authorization:'Bearer '+process.env.MP_ACCESS_TOKEN,'Content-Type':'application/json'},
  body:JSON.stringify({items:[{title:`${ev.name} - boleto`,quantity:qty,unit_price:Number(ev.price_mxn),currency_id:'MXN'}],
   external_reference:o.id,notification_url:b+'/api/webhook',back_urls:{success:back,pending:back,failure:back},auto_return:'approved'})});
 const p=await r.json();
 if(!p.init_point)return res.status(500).json({error:'No se pudo iniciar el pago'});
 res.json({url:p.init_point});
}
