import {sb} from './_db.js';
export default async function handler(req,res){
 if(req.method!=='POST')return res.status(405).end();
 const {data:{user}}=await sb.auth.getUser((req.headers.authorization||'').replace('Bearer ',''));
 if(!user)return res.status(401).json({r:'noauth'});
 const {data:a}=await sb.from('admins').select('user_id').eq('user_id',user.id).maybeSingle();
 if(!a)return res.status(403).json({r:'noauth'});
 const t=String(req.body?.token||'').trim();
 if(!/^[a-f0-9]{32}$/.test(t))return res.json({r:'invalid'});
 const {data:ok}=await sb.from('tickets').update({status:'used',used_at:new Date().toISOString()}).eq('token',t).eq('status','valid').select('events(name)');
 if(ok?.length)return res.json({r:'ok',event:ok[0].events?.name});
 const {data:x}=await sb.from('tickets').select('used_at').eq('token',t).maybeSingle();
 res.json(x?{r:'used',at:x.used_at}:{r:'invalid'});
}
